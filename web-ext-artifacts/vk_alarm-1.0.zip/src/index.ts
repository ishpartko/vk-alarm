import app from './App';

(function() {
  app.builUI();
})();
