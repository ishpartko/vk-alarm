declare module 'vue/dist/vue.min.js' {
  import Vue from 'vue';
  import Vue from 'vue';
  export default Vue;
}
